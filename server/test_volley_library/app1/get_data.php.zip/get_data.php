<?php
$data=array("data_1"=>"Value 1","data_2"=>"Value 2","data_3"=>"Value 3");
echo json_encode($data);
