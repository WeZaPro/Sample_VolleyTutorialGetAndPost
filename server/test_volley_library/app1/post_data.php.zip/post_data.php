<?php
$data=$_REQUEST;
echo json_encode($data);
//now let's create app for volley post and get request
